<?php

/**
 * This file is part of the Tracy (https://tracy.nette.org)
 * Copyright (c) 2004 David Grudl (https://davidgrudl.com)
 */

declare(strict_types=1);

namespace Tracy;


/**
 * @internal
 */
final class DeferredContent
{
	/** @var SessionStorage */
	private $sessionStorage;

	/** @var string */
	private $requestId;

	/** @var bool */
	private $useSession = false;


	public function __construct(SessionStorage $sessionStorage)
	{
		$this->sessionStorage = $sessionStorage;
		$this->requestId = $_SERVER['HTTP_X_TRACY_AJAX'] ?? Helpers::createId();
	}


	public function isAvailable(): bool
	{
		return $this->useSession && $this->sessionStorage->isAvailable();
	}


	public function getRequestId(): string
	{
		return $this->requestId;
	}


	public function &getItems(string $key): array
	{
		$items = &$this->sessionStorage->getData()[$key];
		$items = (array) $items;
		return $items;
	}


	public function addSetup(string $method, $argument): void
	{
		$argument = json_encode($argument, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
		$item = &$this->getItems('setup')[$this->requestId];
		$item['code'] = ($item['code'] ?? '') . "$method($argument);\n";
		$item['time'] = time();
	}


	public function sendAssets(): bool
	{
		if (headers_sent($file, $line) || ob_get_length()) {
			throw new \LogicException(
				__METHOD__ . '() called after some output has been sent. '
				. ($file ? "Output started at $file:$line." : 'Try Tracy\OutputDebugger to find where output started.')
			);
		}

		$asset = $_GET['_tracy_bar'] ?? null;
		if ($asset === 'js') {
			header('Content-Type: application/javascript; charset=UTF-8');
			header('Cache-Control: max-age=864000');
			header_remove('Pragma');
			header_remove('Set-Cookie');
			$this->sendJsCss();
			return true;
		}

		$this->useSession = $this->sessionStorage->isAvailable();
		if (!$this->useSession) {
			return false;
		}

		$this->clean();

		if (is_string($asset) && preg_match('#^content(-ajax)?\.(\w+)$#', $asset, $m)) {
			[, $ajax, $requestId] = $m;
			header('Content-Type: application/javascript; charset=UTF-8');
			header('Cache-Control: max-age=60');
			header_remove('Set-Cookie');
			if (!$ajax) {
				$this->sendJsCss();
			}

			$data = &$this->getItems('setup');
			echo $data[$requestId]['code'] ?? '';
			unset($data[$requestId]);

			return true;
		}

		if (Helpers::isAjax()) {
			header('X-Tracy-Ajax: 1'); // session must be already locked
		}

		return false;
	}


	private function sendJsCss(): void
	{
		$css = array_map('file_get_contents', array_merge([
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../Bar/assets/bar.css',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../assets/toggle.css',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../assets/table-sort.css',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../assets/tabs.css',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../Dumper/assets/dumper-light.css',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../Dumper/assets/dumper-dark.css',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../BlueScreen/assets/bluescreen.css',
		], Debugger::$customCssFiles));

		echo "'use strict';
(function(){
	var el = document.createElement('style');
	el.setAttribute('nonce', document.currentScript.getAttribute('nonce') || document.currentScript.nonce);
	el.className='tracy-debug';
	el.textContent=" . json_encode(Helpers::minifyCss(implode('', $css))) . ";
	document.head.appendChild(el);})
();\n";

		if(Debugger::$customCssStr) echo "(function(){var el = document.createElement('div'); el.className='tracy-debug'; el.innerHTML='".preg_replace('#\s+#u', ' ', Debugger::$customCssStr)."'; document.head.appendChild(el);})();\n";

		array_map(function ($file) { echo '(function() {', file_get_contents($file), '})();'; }, [
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../Bar/assets/bar.js',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../assets/toggle.js',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../assets/table-sort.js',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../assets/tabs.js',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../Dumper/assets/dumper.js',
			'G:/laragon/www/aeroteam/site/modules/TracyDebugger/tracy-2.9.x/src/Tracy/Debugger' . '/../BlueScreen/assets/bluescreen.js',
		]);
		array_map('readfile', Debugger::$customJsFiles);

		if(Debugger::$customJsStr) echo Debugger::$customJsStr;

		if(Debugger::$customBodyStr) echo "(function(){var el = document.createElement('div'); el.className='tracy-debug'; el.innerHTML='".preg_replace('#\s+#u', ' ', Debugger::$customBodyStr)."'; document.body.appendChild(el);})();\n";

	}


	public function clean(): void
	{
		foreach ($this->sessionStorage->getData() as &$items) {
			$items = array_slice((array) $items, -10, null, true);
			$items = array_filter($items, function ($item) {
				return isset($item['time']) && $item['time'] > time() - 60;
			});
		}
	}
}
