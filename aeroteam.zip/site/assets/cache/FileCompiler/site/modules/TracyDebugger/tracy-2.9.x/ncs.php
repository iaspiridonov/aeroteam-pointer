<?php

/**
 * Rules for Nette Coding Standard
 * https://github.com/nette/coding-standard
 */

declare(strict_types=1);

return [
	// src/Tracy/Debugger/Debugger.php
	'ordered_class_elements' => false,
];
