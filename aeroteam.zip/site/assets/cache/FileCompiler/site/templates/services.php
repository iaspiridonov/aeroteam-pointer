<section class="section pb-0">
    <div class="container">
        <div class="row mb-5">
            <div class="col-12">
                <div class="u-h1"><?= $this_page->title ?></div>
            </div>
        </div>
        <div class="row mb-5 service pb-5">
            <div class="col-md-6 col-12 pe-xl-5 pe-md-4 mb-md-0 mb-4">
                <div class="service__gal row">
                    <div class="col-8 pe-2 h-100">
                        <div class="service__gal-main">
                            <a href="/img/serv-main.png" data-fancybox="serv1">
                                <img class="w-100" src="/img/serv-main.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-4 ps-2 h-100">
                        <div class="service__gal-mini">
                            <a href="/img/serv1.png" data-fancybox="serv1">
                                <img class="w-100" src="/img/serv1.png" alt="">
                            </a>
                            <a href="/img/serv2.png" data-fancybox="serv1">
                                <img class="w-100" src="/img/serv2.png" alt="">
                            </a>
                            <a href="/img/serv3.png" data-fancybox="serv1">
                                <img class="w-100" src="/img/serv3.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12 ps-xl-5 ps-md-4">
                <div class="service__info">
                    <!--div class="service__cat">Полет</div-->
                    <div class="service__head mb-1">
                        <div class="service__title">
                            Полеты
                        </div>
                        <!--div class="service__price">1100 леев</div-->
                    </div>
                    <!--a href="img/serv-main.png" class="service__star mb-3" data-fancybox="review2">
                        <div>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star--disable" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                        </div>
                        <span class="service__star-text">2 отзыва</span>
                    </a>
                    <a href="img/serv1.png" class="service__star mb-3 d-none" data-fancybox="review2"></a>
                    <a href="img/serv2.png" class="service__star mb-3 d-none" data-fancybox="review2"></a>
                    <a href="img/serv3.png" class="service__star mb-3 d-none" data-fancybox="review2"></a-->
                    <div class="service__block">
                        <div class="service__text u-color-gray mb-3">Подарочная карта предназначена любителям насладиться незабываемым и красочным приключением – полётом на самолёте.</div>
                        <!-- <div class="service__dop mb-3">
                            <span class="service__dop-text mb-2">Дополнительная услуга</span>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Видеосъемка - 1000 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы снимаем весь полет
                                        </div>
                                    </div>
                                    <div>
                                        <a href="#" class="service__dop-add">
                                            Добавить
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Фотосъемка - 500 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы делаем фотографии до полета и после,<br> в течении 20 минут
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                        </div> -->
                        <div class="button" data-modal="1"><a style='color: white;' href='/flying'>Подробнее</a></div>
                    </div>
                </div>
            </div>
        </div>
        <?php foreach($this_page->services as $s): ?>
        <div class="row mb-5 service pb-5">
            <div class="col-md-6 col-12 pe-xl-5 pe-md-4 mb-md-0 mb-4">
                <div class="service__gal row">
                    <div class="col-8 pe-2 h-100">
                        <div class="service__gal-main">
                            <a href="<?= $s->picture->url ?>" data-fancybox="serv<?= $s ?>">
                                <img class="w-100" src="<?= $s->picture->url ?>" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-4 ps-2 h-100">
                        <div class="service__gal-mini">
                            <?php foreach($s->additional_pictures as $p): ?>
                            <a href="<?= $p->url ?>" data-fancybox="serv<?= $s ?>">
                                <img class="w-100" src="<?= $p->url ?>" alt="">
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12 ps-xl-5 ps-md-4">
                <div class="service__info">
                    <div class="service__cat"><?= $s->category ?></div>
                    <div class="service__head mb-1">
                        <div class="service__title">
                            <?= $s->header ?>
                        </div>
                        <div class="service__price"><?= $s->price ?> леев</div>
                    </div>
                    <?php if($s->stars->id): ?>
                    <a href="<?= $s->review_pictures->first()->url; ?>" class="service__star mb-3" data-fancybox="review<?= $s ?>">
                        <div>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star<?= $s->stars->id < 2 ? '--disable' : '' ?>" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star<?= $s->stars->id < 3 ? '--disable' : '' ?>" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star<?= $s->stars->id < 4 ? '--disable' : '' ?>" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star<?= $s->stars->id < 5 ? '--disable' : '' ?>" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                        </div>
                        <span class="service__star-text">Отзывов: <?= count($s->review_pictures)?></span>
                    </a>
                        <?php foreach($s->review_pictures as $rp): ?>
                            <?php if($s->review_pictures->first()->url == $rp->url) continue ?>
                            <a href="<?= $rp->url ?>" class="service__star mb-3 d-none" data-fancybox="review<?= $s ?>"></a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <div class="service__block">
                        <div class="service__text u-color-gray mb-3"><?= $s->text ?></div>
                        <div class="service__dop mb-3">
                            <span class="service__dop-text mb-2">Дополнительная услуга</span>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Видеосъемка - 1000 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы снимаем весь полет
                                        </div>
                                    </div>
                                    <div>
                                        <a href="#" class="service__dop-add">
                                            Добавить
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Фотосъемка - 500 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы делаем фотографии до полета и после,<br> в течении 20 минут
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                        </div>
                        
                            <div class="button js-open-modal" data-modal="1"><a href="#<?= $s ?>" style="color:white;" class="item">Заказать</a></div>
                        
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <!--div class="row mb-5 service pb-5">
            <div class="col-md-6 col-12 pe-xl-5 pe-md-4 mb-md-0 mb-4">
                <div class="service__gal row">
                    <div class="col-8 pe-2 h-100">
                        <div class="service__gal-main">
                            <a href="img/serv-main.png" data-fancybox="serv1">
                                <img class="w-100" src="img/serv-main.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-4 ps-2 h-100">
                        <div class="service__gal-mini">
                            <a href="img/serv1.png" data-fancybox="serv1">
                                <img class="w-100" src="img/serv1.png" alt="">
                            </a>
                            <a href="img/serv2.png" data-fancybox="serv1">
                                <img class="w-100" src="img/serv2.png" alt="">
                            </a>
                            <a href="img/serv3.png" data-fancybox="serv1">
                                <img class="w-100" src="img/serv3.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12 ps-xl-5 ps-md-4">
                <div class="service__info">
                    <div class="service__cat">Полет</div>
                    <div class="service__head mb-1">
                        <div class="service__title">
                            Полет на дельтаплане
                        </div>
                        <div class="service__price">1100 леев</div>
                    </div>
                    <a href="img/serv-main.png" class="service__star mb-3" data-fancybox="review2">
                        <div>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star--disable" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                        </div>
                        <span class="service__star-text">2 отзыва</span>
                    </a>
                    <a href="img/serv1.png" class="service__star mb-3 d-none" data-fancybox="review2"></a>
                    <a href="img/serv2.png" class="service__star mb-3 d-none" data-fancybox="review2"></a>
                    <a href="img/serv3.png" class="service__star mb-3 d-none" data-fancybox="review2"></a>
                    <div class="service__block">
                        <div class="service__text u-color-gray mb-3">Подарочная карта предназначена любителям насладиться незабываемым и красочным приключением – полётом на самолёте.</div>
                        <div class="service__dop mb-3">
                            <span class="service__dop-text mb-2">Дополнительная услуга</span>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Видеосъемка - 1000 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы снимаем весь полет
                                        </div>
                                    </div>
                                    <div>
                                        <a href="#" class="service__dop-add">
                                            Добавить
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Фотосъемка - 500 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы делаем фотографии до полета и после,<br> в течении 20 минут
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="button js-open-modal" data-modal="1">Заказать</div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="row mb-5 service pb-5">
            <div class="col-md-6 col-12 pe-xl-5 pe-md-4 mb-md-0 mb-4">
                <div class="service__gal row">
                    <div class="col-8 pe-2 h-100">
                        <div class="service__gal-main">
                            <a href="img/serv2-main.png" data-fancybox="serv2">
                                <img class="w-100" src="img/serv2-main.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-4 ps-2 h-100">
                        <div class="service__gal-mini">
                            <a href="img/serv21.png" data-fancybox="serv2">
                                <img class="w-100" src="img/serv21.png" alt="">
                            </a>
                            <a href="img/serv22.png" data-fancybox="serv2">
                                <img class="w-100" src="img/serv22.png" alt="">
                            </a>
                            <a href="img/serv23.png" data-fancybox="serv2">
                                <img class="w-100" src="img/serv23.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12 ps-xl-5 ps-md-4">
                <div class="service__info">
                    <div class="service__cat">Мероприятие</div>
                    <div class="service__head mb-1">
                        <div class="service__title">
                            Предложение руки и сердца
                        </div>
                        <div class="service__price">1500 леев</div>
                    </div>
                    <a href="img/serv2-main.png" class="service__star mb-3" data-fancybox="review3">
                        <div>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                        </div>
                        <span class="service__star-text">10 отзывов</span>
                    </a>
                    <a href="img/serv21.png" class="service__star mb-3 d-none" data-fancybox="review3"></a>
                    <a href="img/serv22.png" class="service__star mb-3 d-none" data-fancybox="review3"></a>
                    <a href="img/serv23.png" class="service__star mb-3 d-none" data-fancybox="review3"></a>
                    <div class="service__block">
                        <div class="service__text u-color-gray mb-3">Подарочная карта предназначена любителям насладиться незабываемым и красочным приключением – полётом на самолёте.</div>
                        <div class="service__dop mb-3">
                            <span class="service__dop-text mb-2">Дополнительная услуга</span>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Видеосъемка - 1000 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы снимаем весь полет
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Фотосъемка - 500 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы делаем фотографии до полета и после,<br> в течении 20 минут
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="button js-open-modal" data-modal="1">Заказать</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-5 service pb-5">
            <div class="col-md-6 col-12 pe-xl-5 pe-md-4 mb-md-0 mb-4">
                <div class="service__gal row">
                    <div class="col-8 pe-2 h-100">
                        <div class="service__gal-main">
                            <a href="img/serv3-main.png" data-fancybox="serv3">
                                <img class="w-100" src="img/serv3-main.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-4 ps-2 h-100">
                        <div class="service__gal-mini">
                            <a href="img/serv31.png" data-fancybox="serv3">
                                <img class="w-100" src="img/serv31.png" alt="">
                            </a>
                            <a href="img/serv32.png" data-fancybox="serv3">
                                <img class="w-100" src="img/serv32.png" alt="">
                            </a>
                            <a href="img/serv33.png" data-fancybox="serv3">
                                <img class="w-100" src="img/serv33.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12 ps-xl-5 ps-md-4">
                <div class="service__info">
                    <div class="service__cat">Экскурсия</div>
                    <div class="service__head mb-1">
                        <div class="service__title">
                            Полет в винодельню Et Cetera
                        </div>
                        <div class="service__price">3000 леев</div>
                    </div>
                    <a href="img/serv3-main.png" class="service__star mb-3" data-fancybox="review4">
                        <div>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star--disable" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                        </div>
                        <span class="service__star-text">2 отзыва</span>
                    </a>
                    <a href="img/serv31.png" class="service__star mb-3 d-none" data-fancybox="review4"></a>
                    <a href="img/serv32.png" class="service__star mb-3 d-none" data-fancybox="review4"></a>
                    <a href="img/serv33.png" class="service__star mb-3 d-none" data-fancybox="review4"></a>
                    <div class="service__block">
                        <div class="service__text u-color-gray mb-3">Подарочная карта предназначена любителям насладиться незабываемым и красочным приключением – полётом на самолёте.</div>
                        <div class="service__dop mb-3">
                            <span class="service__dop-text mb-2">Дополнительная услуга</span>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Видеосъемка - 1000 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы снимаем весь полет
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Фотосъемка - 500 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы делаем фотографии до полета и после,<br> в течении 20 минут
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="button js-open-modal" data-modal="1">Заказать</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-5 service pb-5">
            <div class="col-md-6 col-12 pe-xl-5 pe-md-4 mb-md-0 mb-4">
                <div class="service__gal row">
                    <div class="col-8 pe-2 h-100">
                        <div class="service__gal-main">
                            <a href="img/serv4-main.png" data-fancybox="serv4">
                                <img class="w-100" src="img/serv4-main.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-4 ps-2 h-100">
                        <div class="service__gal-mini">
                            <a href="img/serv41.png" data-fancybox="serv4">
                                <img class="w-100" src="img/serv41.png" alt="">
                            </a>
                            <a href="img/serv42.png" data-fancybox="serv4">
                                <img class="w-100" src="img/serv42.png" alt="">
                            </a>
                            <a href="img/serv43.png" data-fancybox="serv4">
                                <img class="w-100" src="img/serv43.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12 ps-xl-5 ps-md-4">
                <div class="service__info">
                    <div class="service__cat">Прыжок</div>
                    <div class="service__head mb-1">
                        <div class="service__title">
                            Прыжок с парашютом
                        </div>
                        <div class="service__price">2500 леев</div>
                    </div>
                    <a href="img/serv4-main.png" class="service__star mb-3" data-fancybox="review5">
                        <div>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star--disable" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                        </div>
                        <span class="service__star-text">2 отзыва</span>
                    </a>
                    <a href="img/serv41.png" class="service__star mb-3 d-none" data-fancybox="review5"></a>
                    <a href="img/serv42.png" class="service__star mb-3 d-none" data-fancybox="review5"></a>
                    <a href="img/serv43.png" class="service__star mb-3 d-none" data-fancybox="review5"></a>
                    <div class="service__block">
                        <div class="service__text u-color-gray mb-3">Подарочная карта предназначена любителям насладиться незабываемым и красочным приключением – полётом на самолёте.</div>
                        <div class="service__dop mb-3">
                            <span class="service__dop-text mb-2">Дополнительная услуга</span>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Видеосъемка - 1000 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы снимаем весь полет
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Фотосъемка - 500 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы делаем фотографии до полета и после,<br> в течении 20 минут
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="button js-open-modal" data-modal="1">Заказать</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-5 service pb-5">
            <div class="col-md-6 col-12 pe-xl-5 pe-md-4 mb-md-0 mb-4">
                <div class="service__gal row">
                    <div class="col-8 pe-2 h-100">
                        <div class="service__gal-main">
                            <a href="img/serv5-main.png" data-fancybox="serv5">
                                <img class="w-100" src="img/serv5-main.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-4 ps-2 h-100">
                        <div class="service__gal-mini">
                            <a href="img/serv51.png" data-fancybox="serv5">
                                <img class="w-100" src="img/serv51.png" alt="">
                            </a>
                            <a href="img/serv52.png" data-fancybox="serv5">
                                <img class="w-100" src="img/serv52.png" alt="">
                            </a>
                            <a href="img/serv53.png" data-fancybox="serv5">
                                <img class="w-100" src="img/serv53.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12 ps-xl-5 ps-md-4">
                <div class="service__info">
                    <div class="service__cat">Мероприятие</div>
                    <div class="service__head mb-1">
                        <div class="service__title">
                            Gender party
                        </div>
                        <div class="service__price">1100 леев</div>
                    </div>
                    <a href="img/serv5-main.png" class="service__star mb-3" data-fancybox="review5">
                        <div>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star--disable" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                        </div>
                        <span class="service__star-text">2 отзыва</span>
                    </a>
                    <a href="img/serv51.png" class="service__star mb-3 d-none" data-fancybox="review5"></a>
                    <a href="img/serv52.png" class="service__star mb-3 d-none" data-fancybox="review5"></a>
                    <a href="img/serv53.png" class="service__star mb-3 d-none" data-fancybox="review5"></a>
                    <div class="service__block">
                        <div class="service__text u-color-gray mb-3">Подарочная карта предназначена любителям насладиться незабываемым и красочным приключением – полётом на самолёте.</div>
                        <div class="service__dop mb-3">
                            <span class="service__dop-text mb-2">Дополнительная услуга</span>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Видеосъемка - 1000 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы снимаем весь полет
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Фотосъемка - 500 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы делаем фотографии до полета и после,<br> в течении 20 минут
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="button js-open-modal" data-modal="1">Заказать</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mb-5 service pb-5">
            <div class="col-md-6 col-12 pe-xl-5 pe-md-4 mb-md-0 mb-4">
                <div class="service__gal row">
                    <div class="col-8 pe-2 h-100">
                        <div class="service__gal-main">
                            <a href="img/serv6-main.png" data-fancybox="serv6">
                                <img class="w-100" src="img/serv6-main.png" alt="">
                            </a>
                        </div>
                    </div>
                    <div class="col-4 ps-2 h-100">
                        <div class="service__gal-mini">
                            <a href="img/serv61.png" data-fancybox="serv6">
                                <img class="w-100" src="img/serv61.png" alt="">
                            </a>
                            <a href="img/serv62.png" data-fancybox="serv6">
                                <img class="w-100" src="img/serv62.png" alt="">
                            </a>
                            <a href="img/serv63.png" data-fancybox="serv6">
                                <img class="w-100" src="img/serv63.png" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-12 ps-xl-5 ps-md-4">
                <div class="service__info">
                    <div class="service__cat">Полет</div>
                    <div class="service__head mb-1">
                        <div class="service__title">
                            Аренда самолета
                        </div>
                        <div class="service__price">5000 леев</div>
                    </div>
                    <a href="img/serv6-main.png" class="service__star mb-3" data-fancybox="review6">
                        <div>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                            <svg class="o-star--disable" width="17" height="16" viewBox="0 0 17 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.54894 0.927052C7.8483 0.0057416 9.1517 0.00573945 9.45106 0.92705L10.6329 4.56434C10.7668 4.97636 11.1507 5.25532 11.5839 5.25532H15.4084C16.3771 5.25532 16.7799 6.49494 15.9962 7.06434L12.9021 9.31231C12.5516 9.56695 12.405 10.0183 12.5389 10.4303L13.7207 14.0676C14.02 14.9889 12.9656 15.7551 12.1818 15.1857L9.08779 12.9377C8.7373 12.6831 8.2627 12.6831 7.91222 12.9377L4.81815 15.1857C4.03444 15.7551 2.97996 14.9889 3.27931 14.0676L4.46114 10.4303C4.59501 10.0183 4.44835 9.56695 4.09787 9.31231L1.00381 7.06434C0.220092 6.49494 0.622867 5.25532 1.59159 5.25532H5.41606C5.84929 5.25532 6.23324 4.97636 6.36712 4.56434L7.54894 0.927052Z" fill="#DBDBDB"/>
                            </svg>
                        </div>
                        <span class="service__star-text">2 отзыва</span>
                    </a>
                    <a href="img/serv61.png" class="service__star mb-3 d-none" data-fancybox="review6"></a>
                    <a href="img/serv62.png" class="service__star mb-3 d-none" data-fancybox="review6"></a>
                    <a href="img/serv63.png" class="service__star mb-3 d-none" data-fancybox="review6"></a>
                    <div class="service__block">
                        <div class="service__text u-color-gray mb-3">Подарочная карта предназначена любителям насладиться незабываемым и красочным приключением – полётом на самолёте.</div>
                        <div class="service__dop mb-3">
                            <span class="service__dop-text mb-2">Дополнительная услуга</span>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Видеосъемка - 1000 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы снимаем весь полет
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                            <div class="service__dop-item">
                                <div class="service__dop-block">
                                    <div>
                                        <div class="service__dop-name">
                                            Фотосъемка - 500 леев
                                        </div>
                                        <div class="service__dop-desc">
                                            Мы делаем фотографии до полета и после,<br> в течении 20 минут
                                        </div>
                                    </div>
                                    <a href="#" class="service__dop-add">
                                        Добавить
                                    </a>
                                </div>
                            </div>
                        </div>
                        <a href="#" class="button js-open-modal" data-modal="1">Заказать</a>
                    </div>
                </div>
            </div>
        </div-->

    </div>
</section>  
