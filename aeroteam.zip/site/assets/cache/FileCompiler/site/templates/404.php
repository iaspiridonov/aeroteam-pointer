<style>
    .section--weekend-404 ~ section {
        display:none;
    }
</style>
<section style="width: 100%;
    height: 80vh;padding: 0 !important;" class="section section--weekend section--weekend-404">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-4 col-sm-6 col-12 mb-4 mb-sm-0">
                <div style="padding-top:50px;" class="u-h1 mb-3">
                    Страница не найдена...
                </div>
                <div class="u-text u-text u-text--gray">
                    Запрашиваемая страница не найдена. Попробуйте начать с главной страницы. 
                </div>
                <a href="/" style="background-color: #395cb8;padding: 0 15px;height: 40px;display: -webkit-inline-box;display: -ms-inline-flexbox;display: inline-flex;-webkit-box-align: center;-ms-flex-align: center;align-items: center;-webkit-box-pack: center;-ms-flex-pack: center;justify-content: center;color: #fff;border: 1px solid #395cb8;border-radius: 50px;cursor: pointer;-webkit-transition: .3s;transition: .3s;text-decoration: none;text-align: center;-webkit-box-orient: vertical;-webkit-box-direction: normal;-ms-flex-direction: column;flex-direction: column;min-width: 120px;margin-top: 30px;">Вернуться на главную</a>
            </div>
            <div class="col-md-8 col-sm-6 col-12 position-relative">
                <div class="swiper js-swiper-weekend">
                    <!-- Additional required wrapper -->
                   
                    </div>
                    </div>

            </div>
        </div>
    </div>
</section>