<?php 
if($_POST['name'] && $_POST['phone']) {
    $to      = 'as@pointer.global';
    $subject = 'Заявка на звонок';
    $message = 'ФИО: ' . $_POST['name'] . ', телефон:' . $_POST['phone'];
    $headers = 'From: webmaster@example.com' . "\r\n" .
        'Reply-To: webmaster@example.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();

    mail($to, $subject, $message, $headers);
    header('Location: /spasibo.php');
    die;
}